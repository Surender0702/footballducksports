<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo get_bloginfo('name') . ' | ' . get_the_title(); ?></title>
    <?php wp_head(); ?>
</head>
<body <?php body_class(); ?>>

<nav class="navbar navbar-expand-lg navbar-dark">
    <div class="container">
        <a class="navbar-brand" href="<?php echo esc_url(home_url('/')); ?>">
            <?php 
            // Get the custom logo
            if (has_custom_logo()) {
                the_custom_logo(); // Show uploaded logo
            } else {
                echo bloginfo('name'); // Show site name if no logo is uploaded
            }
            ?>
        </a>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarNav">
            <?php
            wp_nav_menu(array(
                'theme_location' => 'primary', // Assign a menu location in WordPress
                'menu_class'     => 'navbar-nav ms-auto',
                'container'      => false,
                'fallback_cb'    => false, // Prevents displaying a default menu if none is set
                'depth'          => 2, // Enables dropdowns
                'walker'         => new Bootstrap_NavWalker() // Custom walker for Bootstrap compatibility
            ));
            ?>
        </div>
    </div>
</nav>
