<?php
function football_enqueue_styles() {
    // Enqueue Bootstrap CSS
    wp_enqueue_style('bootstrap-css', 'https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css', array(), null);

    // Enqueue Google Fonts
    wp_enqueue_style('google-fonts', 'https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;700&display=swap', array(), null);

    // Enqueue Theme Stylesheet
    wp_enqueue_style('theme-style', get_stylesheet_uri(), array(), filemtime(get_template_directory() . '/style.css'));

    // Enqueue Bootstrap JS
    wp_enqueue_script('bootstrap-js', 'https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js', array(), null, true);
}
add_action('wp_enqueue_scripts', 'football_enqueue_styles');



function football_theme_setup() {
    add_theme_support('title-tag');
    add_theme_support('post-thumbnails');
    add_theme_support('custom-logo');
    add_theme_support('automatic-feed-links'); // Added for better RSS support
}
add_action('after_setup_theme', 'football_theme_setup');

function football_widgets_init() {
    register_sidebar(array(
        'name'          => __('Latest Updates', 'football'),
        'id'            => 'latest-updates',
        'before_widget' => '<div class="update-item">',
        'after_widget'  => '</div>',
        'before_title'  => '<h3 class="section-title">',
        'after_title'   => '</h3>',
    ));
}
add_action('widgets_init', 'football_widgets_init');

function mytheme_custom_logo_setup() {
    $defaults = array(
        'height'      => 100,
        'width'       => 300,
        'flex-height' => true,
        'flex-width'  => true,
    );
    add_theme_support('custom-logo', $defaults);
}
add_action('after_setup_theme', 'mytheme_custom_logo_setup');

function create_events_post_type() {
    register_post_type('events',
        array(
            'labels'      => array(
                'name'          => __('Events', 'football'),
                'singular_name' => __('Event', 'football'),
            ),
            'public'      => true,
            'has_archive' => false,
            'supports'    => array('title', 'editor', 'thumbnail', 'custom-fields'),
            'menu_icon'   => 'dashicons-calendar-alt', // Corrected icon
            'show_in_rest' => true, // Enables Gutenberg editor support
        )
    );
}
add_action('init', 'create_events_post_type');


function register_event_type_taxonomy() {
    register_taxonomy(
        'event_type',
        'events',
        array(
            'label'        => 'Event Type',
            'rewrite'      => array('slug' => 'event-type'),
            'hierarchical' => true,
        )
    );
}
add_action('init', 'register_event_type_taxonomy');


function football_register_menus() {
    register_nav_menus(array(
        'primary' => __('Primary Menu', 'football'),
    ));
}
add_action('init', 'football_register_menus');

class Bootstrap_NavWalker extends Walker_Nav_Menu {
    function start_lvl(&$output, $depth = 0, $args = null) {
        $output .= '<ul class="dropdown-menu">';
    }
    function start_el(&$output, $item, $depth = 0, $args = null, $id = 0) {
        $classes = empty($item->classes) ? array() : (array) $item->classes;
        $class_names = join(' ', apply_filters('nav_menu_css_class', array_filter($classes), $item));
        $output .= '<li class="nav-item ' . esc_attr($class_names) . '">';
        $output .= '<a class="nav-link" href="' . esc_url($item->url) . '">' . esc_html($item->title) . '</a>';
    }
}


?>
