<section id="latest-event" class="container content-section">
    <div class="row">
        <!-- Left Side: YouTube Videos -->
        <div class="col-md-6">
    <h2 class="section-title">HIGHLIGHTS</h2>
    <hr class="section-divider">
    <div class="video-container">
        <?php
        $args = array(
            'post_type'      => 'events',
            'posts_per_page' => 2,
            'order'          => 'DESC',
            'orderby'        => 'date',
            'tax_query'      => array(
                array(
                    'taxonomy' => 'event_type', // Custom taxonomy
                    'field'    => 'slug',
                    'terms'    => 'youtube' // Only fetch events tagged as YouTube
                ),
            ),
        );
        
        $query = new WP_Query($args);
        if ($query->have_posts()) :
            while ($query->have_posts()) : $query->the_post();
                $video_url = get_field('youtube_video_url'); // Fetch from ACF
                if ($video_url) :
                    preg_match('/[\\?\\&]v=([^\\?\\&]+)/', $video_url, $matches);
                    $video_id = isset($matches[1]) ? $matches[1] : ''; // Extract video ID
        ?>
                <div class="embed-responsive embed-responsive-16by9">
                    <iframe class="embed-responsive-item" src="https://www.youtube.com/embed/<?php echo esc_attr($video_id); ?>" allowfullscreen></iframe>
                </div>
        <?php
                endif;
            endwhile;
            wp_reset_postdata();
        else :
            echo "<p>No videos available.</p>";
        endif;
        ?>
    </div>
</div>


        <!-- Right Side: Latest Updates -->
        <div class="col-md-6">
    <h3 class="section-title">LATEST UPDATES</h3>
    <hr class="section-divider">
    <ul class="latest-updates">
        <?php
      $args = array(
        'post_type'      => 'events',
        'posts_per_page' => 5,
        'order'          => 'DESC',
        'orderby'        => 'date',
        'tax_query'      => array(
            array(
                'taxonomy' => 'event_type', // Custom taxonomy
                'field'    => 'slug',
                'terms'    => 'latest-updates' // Only fetch non-YouTube updates
            ),
        ),
    );
    
        $query = new WP_Query($args);
        
        if ($query->have_posts()) :
            while ($query->have_posts()) : $query->the_post();
                $event_title = get_the_title(); // Get Event Title
                $event_date = get_the_date('F j, Y'); // Get Published Date
                $event_description = get_the_excerpt(); // Get Event Excerpt
        ?>
                <li class="update-item">
                    <strong><?php echo esc_html($event_title); ?></strong>: 
                    <?php echo esc_html($event_description); ?> <br>
                    <small>Date: <?php echo esc_html($event_date); ?></small>
                </li>
        <?php
            endwhile;
            wp_reset_postdata();
        else :
            echo "<p>No updates available.</p>";
        endif;
        ?>
    </ul>
</div>

    </div>
</section>
