<?php get_header(); ?>
<div id="customCarousel" class="carousel slide carousel-fade" data-bs-ride="carousel">
    <div class="carousel-indicators">
        <?php
        $slides = new WP_Query(array('post_type' => 'custom_slider', 'posts_per_page' => -1));
        $count = 0;
        while ($slides->have_posts()) : $slides->the_post(); ?>
            <button type="button" data-bs-target="#customCarousel" data-bs-slide-to="<?php echo $count; ?>" class="<?php echo ($count === 0) ? 'active' : ''; ?>" aria-current="true"></button>
        <?php $count++; endwhile; wp_reset_postdata(); ?>
    </div>

    <div class="carousel-inner">
        <?php
        $active = 'active';
        if ($slides->have_posts()) :
            while ($slides->have_posts()) : $slides->the_post();
                $image = get_the_post_thumbnail_url(get_the_ID(), 'full');
                $text = get_post_meta(get_the_ID(), 'custom_slider_text', true);
                $button_text = get_post_meta(get_the_ID(), 'custom_slider_button_text', true);
                $button_link = get_post_meta(get_the_ID(), 'custom_slider_button_link', true);
        ?>
            <div class="carousel-item <?php echo $active; ?>">
                <div class="slider-image-container">
                    <img src="<?php echo esc_url($image); ?>" class="d-block w-100" alt="<?php the_title(); ?>">
                    <div class="slider-overlay"></div>
                </div>
                <div class="carousel-caption">
                    <h5 class="animate__animated animate__fadeInDown">
                        <?php the_title(); ?>
                    </h5>
                    
                    <?php if ($text) : ?>
                        <p class="animate__animated animate__fadeInUp">
                            <?php echo esc_html($text); ?>
                        </p>
                    <?php endif; ?>
                
                    <?php if ($button_text && $button_link) : ?>
                        <a href="<?php echo esc_url($button_link); ?>" class="btn btn-registration">
                            <?php echo esc_html($button_text); ?>
                        </a>
                    <?php endif; ?>
                </div>
            </div>
        <?php
            $active = '';
            endwhile;
        endif;
        wp_reset_postdata();
        ?>
    </div>

    <button class="carousel-control-prev" type="button" data-bs-target="#customCarousel" data-bs-slide="prev">
        <span class="carousel-control-prev-icon"></span>
    </button>
    <button class="carousel-control-next" type="button" data-bs-target="#customCarousel" data-bs-slide="next">
        <span class="carousel-control-next-icon"></span>
    </button>
</div>

<div class="text-center mt-4">
    <a href="<?php echo get_permalink(get_page_by_path('online-regisration')); ?>" class="btn btn-registration">
        Register Online
    </a>
</div>
<?php get_template_part('template-parts/events'); ?>

<!-- About Us Section -->
<section id="about" class="container py-5">
    <div class="row align-items-center">
        <?php
        // Fetch the latest "About Us" post from the 'about-us' category
        $about_query = new WP_Query(array(
            'category_name' => 'about-us',
            'posts_per_page' => 1
        ));

        if ($about_query->have_posts()) :
            while ($about_query->have_posts()) : $about_query->the_post();
                $about_us_content = get_field('about_us_content'); // ACF Field for content
                $about_us_image = get_field('about_us_image'); // ACF Field for image
        ?>
                <div class="col-lg-6">
                    <h2 class="section-title text-uppercase fw-bold mb-4">About Us</h2>
                    <div class="about-content">
                        <?php if ($about_us_content) : ?>
                            <p class="lead text-muted"><?php echo wp_kses_post($about_us_content); ?></p>
                        <?php else : ?>
                            <p class="text-muted"><?php echo apply_filters('the_content', get_the_content()); ?></p>
                        <?php endif; ?>
                    </div>
                </div>
                <div class="col-lg-6 text-center">
                    <div class="about-image">
                        <?php if ($about_us_image) : ?>
                            <img src="<?php echo esc_url($about_us_image['url']); ?>" class="img-fluid rounded shadow-lg" alt="About Us">
                        <?php else : ?>
                            <img src="default-image.jpg" class="img-fluid rounded shadow-lg" alt="Default Image">
                        <?php endif; ?>
                    </div>
                </div>
        <?php
            endwhile;
            wp_reset_postdata();
        else :
            echo "<p class='text-center text-muted'>No About Us content available. Please update from the WordPress admin.</p>";
        endif;
        ?>
    </div>
</section>

<!-- Skill Development Section -->
<section id="skill-development" class="container py-5">
    <div class="row align-items-center">
        <?php
        // Fetch the latest "Skill Development" post from the 'skill-development' category
        $skill_query = new WP_Query(array(
            'category_name' => 'skill-development',
            'posts_per_page' => 1
        ));

        if ($skill_query->have_posts()) :
            while ($skill_query->have_posts()) : $skill_query->the_post();
                $skill_dev_content = get_field('skill_dev_content'); // ACF Field for content
                $skill_dev_image = get_field('skill_dev_image'); // ACF Field for image
        ?>
              
                <div class="col-lg-6 text-center">
                    <div class="skill-image">
                        <?php if ($skill_dev_image) : ?>
                            <img src="<?php echo esc_url($skill_dev_image['url']); ?>" class="img-fluid rounded shadow-lg" alt="Skill Development">
                        <?php else : ?>
                            <img src="default-image.jpg" class="img-fluid rounded shadow-lg" alt="Default Image">
                        <?php endif; ?>
                    </div>
                </div>
                <div class="col-lg-6">
                    <h2 class="section-title text-uppercase fw-bold mb-4">Skill Development</h2>
                    <div class="skill-content">
                        <?php if ($skill_dev_content) : ?>
                            <p class="lead text-muted"><?php echo wp_kses_post($skill_dev_content); ?></p>
                        <?php else : ?>
                            <p class="text-muted"><?php echo apply_filters('the_content', get_the_content()); ?></p>
                        <?php endif; ?>
                    </div>
                </div>
        <?php
            endwhile;
            wp_reset_postdata();
        else :
            echo "<p class='text-center text-muted'>No Skill Development content available. Please update from the WordPress admin.</p>";
        endif;
        ?>
    </div>
</section>
<!-- Academic Benefit Section -->
<!-- <section id="academic-benefit" class="container py-5">
    <div class="row align-items-center">
        <?php
        // Fetch the latest "Academic Benefit" post from the 'academic-benefit' category
        $academic_query = new WP_Query(array(
            'category_name' => 'academic-benefit',
            'posts_per_page' => 1
        ));

        if ($academic_query->have_posts()) :
            while ($academic_query->have_posts()) : $academic_query->the_post();
                $academic_content = get_field('academic_content'); // ACF Field for content
                $academic_image = get_field('academic_image'); // ACF Field for image
        ?>
                <div class="col-lg-6">
                    <h2 class="section-title text-uppercase fw-bold mb-4">Academic Benefit</h2>
                    <div class="academic-content">
                        <?php if ($academic_content) : ?>
                            <p class="lead text-muted"><?php echo wp_kses_post($academic_content); ?></p>
                        <?php else : ?>
                            <p class="text-muted"><?php echo apply_filters('the_content', get_the_content()); ?></p>
                        <?php endif; ?>
                    </div>
                </div>
                <div class="col-lg-6 text-center">
                    <div class="academic-image">
                        <?php if ($academic_image) : ?>
                            <img src="<?php echo esc_url($academic_image['url']); ?>" class="img-fluid rounded shadow-lg" alt="Academic Benefit">
                        <?php else : ?>
                            <img src="default-image.jpg" class="img-fluid rounded shadow-lg" alt="Default Image">
                        <?php endif; ?>
                    </div>
                </div>
        <?php
            endwhile;
            wp_reset_postdata();
        else :
            echo "<p class='text-center text-muted'>No Academic Benefit content available. Please update from the WordPress admin.</p>";
        endif;
        ?>
    </div>
</section>
 -->
<?php
// Fetch ACF fields
$contact_title = get_field('contact_title') ?: 'Contact Us';
$contact_subtitle = get_field('contact_subtitle') ?: 'Get in touch with us for any queries or information';
$contact_email = get_field('contact_email') ?: 'football.ducksports@gmail.com';
$contact_phone = get_field('contact_phone') ?: '+91 9821440038';

// Default locations list (white text)
$contact_address = get_field('contact_address') ?: ' 
<ul style="list-style:none; padding-left:0; line-height:1.8; color:#ffffff; font-size:16px;">
    <li>📍 The Shree Jee School, Lakewood City, Surajkund Road, Faridabad</li>
    <li>📍 KL Mehta Dayanand Public School,  Sector -17, Faridabad</li>
    <li>📍 Pt. Yadram Public School, Bhajanpura, Delhi</li>
    <li>📍 Dwarka Sec -2, Mahalaxmi APT</li>
</ul>
';
?>

<!-- <?php echo do_shortcode('[pif_form]'); ?> -->

<section id="contact" class="contact-section">
    <div class="container">
        <h2 class="section-title" style="color:#ffffff;"><?php echo esc_html($contact_title); ?></h2>
        <p class="section-subtitle" style="color:#ffffff;"><?php echo esc_html($contact_subtitle); ?></p>

        <div class="row">
            <!-- Left Side: Contact Details -->
            <div class="col-md-12 contact-details">
                <div class="contact-info">
                    <i class="fas fa-envelope" style="color:#ffffff;"></i>
                    <h4 style="color:#ffffff;">Email</h4>
                    <p style="color:#ffffff;"><?php echo esc_html($contact_email); ?></p>
                </div>
                <div class="contact-info">
                    <i class="fas fa-phone-alt" style="color:#ffffff;"></i>
                    <h4 style="color:#ffffff;">Phone</h4>
                    <p style="color:#ffffff;"><?php echo esc_html($contact_phone); ?></p>
                </div>
                <div class="contact-info">
                    <i class="fas fa-map-marker-alt" style="color:#ffffff;"></i>
                    <h4 style="color:#ffffff;">Address</h4>
                    <?php echo $contact_address; // Display white text list ?>
                </div>
            </div>
        </div>
    </div>
</section>


<?php get_footer(); ?>
