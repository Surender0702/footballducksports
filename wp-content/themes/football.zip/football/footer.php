<footer class="text-center">
    <p>&copy; <?php echo date('Y'); ?> Football Academy. All rights reserved.</p>
</footer>

<?php wp_footer(); ?>
<?php echo do_shortcode('[manual_ai_chatbot]'); ?>

</body>
</html>
